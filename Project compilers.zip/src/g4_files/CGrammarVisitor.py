# Generated from ./src/g4_files/CGrammar.g4 by ANTLR 4.9.3
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .CGrammarParser import CGrammarParser
else:
    from CGrammarParser import CGrammarParser

# This class defines a complete generic visitor for a parse tree produced by CGrammarParser.

class CGrammarVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by CGrammarParser#startRule.
    def visitStartRule(self, ctx:CGrammarParser.StartRuleContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#expr.
    def visitExpr(self, ctx:CGrammarParser.ExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#variable.
    def visitVariable(self, ctx:CGrammarParser.VariableContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#mathExpr.
    def visitMathExpr(self, ctx:CGrammarParser.MathExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#binOp.
    def visitBinOp(self, ctx:CGrammarParser.BinOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#unOp.
    def visitUnOp(self, ctx:CGrammarParser.UnOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#logOp.
    def visitLogOp(self, ctx:CGrammarParser.LogOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#compOp.
    def visitCompOp(self, ctx:CGrammarParser.CompOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#type.
    def visitType(self, ctx:CGrammarParser.TypeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#value.
    def visitValue(self, ctx:CGrammarParser.ValueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CGrammarParser#printf.
    def visitPrintf(self, ctx:CGrammarParser.PrintfContext):
        return self.visitChildren(ctx)



del CGrammarParser