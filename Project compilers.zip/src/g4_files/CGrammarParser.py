# Generated from ./src/g4_files/CGrammar.g4 by ANTLR 4.9.3
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3!")
        buf.write("\177\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4")
        buf.write("\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\3\2\7\2\32\n")
        buf.write("\2\f\2\16\2\35\13\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\5\3,\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\5\3\66\n\3\3\3\3\3\7\3:\n\3\f\3\16\3=\13\3\3\4")
        buf.write("\3\4\3\4\5\4B\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\5\5M\n\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\7\5[\n\5\f\5\16\5^\13\5\3\6\3\6\3\7\3\7\3\b\3\b\3")
        buf.write("\t\3\t\3\n\3\n\3\n\3\n\5\nl\n\n\3\n\3\n\7\np\n\n\f\n\16")
        buf.write("\ns\13\n\3\13\3\13\3\f\3\f\3\f\3\f\5\f{\n\f\3\f\3\f\3")
        buf.write("\f\2\5\4\b\22\r\2\4\6\b\n\f\16\20\22\24\26\2\t\5\2\t\t")
        buf.write("\13\13\24\24\5\2\b\b\n\n\30\30\4\2\t\t\13\13\3\2\22\23")
        buf.write("\4\2\f\16\25\27\4\2\b\13\30\30\3\2\4\6\2\u0088\2\33\3")
        buf.write("\2\2\2\4\65\3\2\2\2\6A\3\2\2\2\bL\3\2\2\2\n_\3\2\2\2\f")
        buf.write("a\3\2\2\2\16c\3\2\2\2\20e\3\2\2\2\22k\3\2\2\2\24t\3\2")
        buf.write("\2\2\26v\3\2\2\2\30\32\5\4\3\2\31\30\3\2\2\2\32\35\3\2")
        buf.write("\2\2\33\31\3\2\2\2\33\34\3\2\2\2\34\36\3\2\2\2\35\33\3")
        buf.write("\2\2\2\36\37\7\2\2\3\37\3\3\2\2\2 !\b\3\1\2!\66\5\b\5")
        buf.write("\2\"\66\5\26\f\2#$\5\22\n\2$%\5\6\4\2%\66\3\2\2\2&\'\5")
        buf.write("\6\4\2\'(\7\17\2\2()\5\4\3\7)\66\3\2\2\2*,\7\7\2\2+*\3")
        buf.write("\2\2\2+,\3\2\2\2,-\3\2\2\2-.\5\22\n\2./\5\6\4\2/\60\7")
        buf.write("\17\2\2\60\61\5\4\3\6\61\66\3\2\2\2\62\63\7\36\2\2\63")
        buf.write("\66\5\6\4\2\64\66\5\6\4\2\65 \3\2\2\2\65\"\3\2\2\2\65")
        buf.write("#\3\2\2\2\65&\3\2\2\2\65+\3\2\2\2\65\62\3\2\2\2\65\64")
        buf.write("\3\2\2\2\66;\3\2\2\2\678\f\3\2\28:\7\31\2\29\67\3\2\2")
        buf.write("\2:=\3\2\2\2;9\3\2\2\2;<\3\2\2\2<\5\3\2\2\2=;\3\2\2\2")
        buf.write(">?\7\b\2\2?B\5\6\4\2@B\7\35\2\2A>\3\2\2\2A@\3\2\2\2B\7")
        buf.write("\3\2\2\2CD\b\5\1\2DE\t\2\2\2EM\5\b\5\nFG\7\20\2\2GH\5")
        buf.write("\b\5\2HI\7\21\2\2IM\3\2\2\2JM\5\24\13\2KM\5\6\4\2LC\3")
        buf.write("\2\2\2LF\3\2\2\2LJ\3\2\2\2LK\3\2\2\2M\\\3\2\2\2NO\f\t")
        buf.write("\2\2OP\t\3\2\2P[\5\b\5\nQR\f\b\2\2RS\t\4\2\2S[\5\b\5\t")
        buf.write("TU\f\7\2\2UV\t\5\2\2V[\5\b\5\bWX\f\6\2\2XY\t\6\2\2Y[\5")
        buf.write("\b\5\7ZN\3\2\2\2ZQ\3\2\2\2ZT\3\2\2\2ZW\3\2\2\2[^\3\2\2")
        buf.write("\2\\Z\3\2\2\2\\]\3\2\2\2]\t\3\2\2\2^\\\3\2\2\2_`\t\7\2")
        buf.write("\2`\13\3\2\2\2ab\t\4\2\2b\r\3\2\2\2cd\t\5\2\2d\17\3\2")
        buf.write("\2\2ef\t\6\2\2f\21\3\2\2\2gh\b\n\1\2hl\7\32\2\2il\7\33")
        buf.write("\2\2jl\7\34\2\2kg\3\2\2\2ki\3\2\2\2kj\3\2\2\2lq\3\2\2")
        buf.write("\2mn\f\3\2\2np\7\b\2\2om\3\2\2\2ps\3\2\2\2qo\3\2\2\2q")
        buf.write("r\3\2\2\2r\23\3\2\2\2sq\3\2\2\2tu\t\b\2\2u\25\3\2\2\2")
        buf.write("vw\7\3\2\2wz\7\20\2\2x{\7\35\2\2y{\5\24\13\2zx\3\2\2\2")
        buf.write("zy\3\2\2\2{|\3\2\2\2|}\7\21\2\2}\27\3\2\2\2\r\33+\65;")
        buf.write("ALZ\\kqz")
        return buf.getvalue()


class CGrammarParser ( Parser ):

    grammarFileName = "CGrammar.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'printf'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'const'", "'*'", "'-'", "'/'", "'+'", 
                     "'<'", "'>'", "'=='", "'='", "'('", "')'", "'&&'", 
                     "'||'", "'!'", "'<='", "'>='", "'!='", "'%'", "';'", 
                     "'char'", "'float'", "'int'", "<INVALID>", "'&'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "INT", "FLOAT", "CHAR", 
                      "CONST", "MUL", "MIN", "DIS", "PLUS", "LT", "GT", 
                      "EQ", "ASS", "LBR", "RBR", "AND", "OR", "NOT", "LTE", 
                      "GTE", "NE", "MOD", "SEMICOL", "CHARTYPE", "FLOATTYPE", 
                      "INTTYPE", "VarName", "REF", "BlockComment", "Comment", 
                      "WS" ]

    RULE_startRule = 0
    RULE_expr = 1
    RULE_variable = 2
    RULE_mathExpr = 3
    RULE_binOp = 4
    RULE_unOp = 5
    RULE_logOp = 6
    RULE_compOp = 7
    RULE_type = 8
    RULE_value = 9
    RULE_printf = 10

    ruleNames =  [ "startRule", "expr", "variable", "mathExpr", "binOp", 
                   "unOp", "logOp", "compOp", "type", "value", "printf" ]

    EOF = Token.EOF
    T__0=1
    INT=2
    FLOAT=3
    CHAR=4
    CONST=5
    MUL=6
    MIN=7
    DIS=8
    PLUS=9
    LT=10
    GT=11
    EQ=12
    ASS=13
    LBR=14
    RBR=15
    AND=16
    OR=17
    NOT=18
    LTE=19
    GTE=20
    NE=21
    MOD=22
    SEMICOL=23
    CHARTYPE=24
    FLOATTYPE=25
    INTTYPE=26
    VarName=27
    REF=28
    BlockComment=29
    Comment=30
    WS=31

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.3")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StartRuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CGrammarParser.EOF, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CGrammarParser.ExprContext)
            else:
                return self.getTypedRuleContext(CGrammarParser.ExprContext,i)


        def getRuleIndex(self):
            return CGrammarParser.RULE_startRule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStartRule" ):
                listener.enterStartRule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStartRule" ):
                listener.exitStartRule(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStartRule" ):
                return visitor.visitStartRule(self)
            else:
                return visitor.visitChildren(self)




    def startRule(self):

        localctx = CGrammarParser.StartRuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_startRule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 25
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.T__0) | (1 << CGrammarParser.INT) | (1 << CGrammarParser.FLOAT) | (1 << CGrammarParser.CHAR) | (1 << CGrammarParser.CONST) | (1 << CGrammarParser.MUL) | (1 << CGrammarParser.MIN) | (1 << CGrammarParser.PLUS) | (1 << CGrammarParser.LBR) | (1 << CGrammarParser.NOT) | (1 << CGrammarParser.CHARTYPE) | (1 << CGrammarParser.FLOATTYPE) | (1 << CGrammarParser.INTTYPE) | (1 << CGrammarParser.VarName) | (1 << CGrammarParser.REF))) != 0):
                self.state = 22
                self.expr(0)
                self.state = 27
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 28
            self.match(CGrammarParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mathExpr(self):
            return self.getTypedRuleContext(CGrammarParser.MathExprContext,0)


        def printf(self):
            return self.getTypedRuleContext(CGrammarParser.PrintfContext,0)


        def type(self):
            return self.getTypedRuleContext(CGrammarParser.TypeContext,0)


        def variable(self):
            return self.getTypedRuleContext(CGrammarParser.VariableContext,0)


        def ASS(self):
            return self.getToken(CGrammarParser.ASS, 0)

        def expr(self):
            return self.getTypedRuleContext(CGrammarParser.ExprContext,0)


        def CONST(self):
            return self.getToken(CGrammarParser.CONST, 0)

        def REF(self):
            return self.getToken(CGrammarParser.REF, 0)

        def SEMICOL(self):
            return self.getToken(CGrammarParser.SEMICOL, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CGrammarParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 51
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.state = 31
                self.mathExpr(0)
                pass

            elif la_ == 2:
                self.state = 32
                self.printf()
                pass

            elif la_ == 3:
                self.state = 33
                self.type(0)
                self.state = 34
                self.variable()
                pass

            elif la_ == 4:
                self.state = 36
                self.variable()
                self.state = 37
                self.match(CGrammarParser.ASS)
                self.state = 38
                self.expr(5)
                pass

            elif la_ == 5:
                self.state = 41
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==CGrammarParser.CONST:
                    self.state = 40
                    self.match(CGrammarParser.CONST)


                self.state = 43
                self.type(0)
                self.state = 44
                self.variable()
                self.state = 45
                self.match(CGrammarParser.ASS)
                self.state = 46
                self.expr(4)
                pass

            elif la_ == 6:
                self.state = 48
                self.match(CGrammarParser.REF)
                self.state = 49
                self.variable()
                pass

            elif la_ == 7:
                self.state = 50
                self.variable()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 57
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CGrammarParser.ExprContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                    self.state = 53
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 54
                    self.match(CGrammarParser.SEMICOL) 
                self.state = 59
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class VariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MUL(self):
            return self.getToken(CGrammarParser.MUL, 0)

        def variable(self):
            return self.getTypedRuleContext(CGrammarParser.VariableContext,0)


        def VarName(self):
            return self.getToken(CGrammarParser.VarName, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable" ):
                return visitor.visitVariable(self)
            else:
                return visitor.visitChildren(self)




    def variable(self):

        localctx = CGrammarParser.VariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_variable)
        try:
            self.state = 63
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [CGrammarParser.MUL]:
                self.enterOuterAlt(localctx, 1)
                self.state = 60
                self.match(CGrammarParser.MUL)
                self.state = 61
                self.variable()
                pass
            elif token in [CGrammarParser.VarName]:
                self.enterOuterAlt(localctx, 2)
                self.state = 62
                self.match(CGrammarParser.VarName)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MathExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mathExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CGrammarParser.MathExprContext)
            else:
                return self.getTypedRuleContext(CGrammarParser.MathExprContext,i)


        def PLUS(self):
            return self.getToken(CGrammarParser.PLUS, 0)

        def MIN(self):
            return self.getToken(CGrammarParser.MIN, 0)

        def NOT(self):
            return self.getToken(CGrammarParser.NOT, 0)

        def LBR(self):
            return self.getToken(CGrammarParser.LBR, 0)

        def RBR(self):
            return self.getToken(CGrammarParser.RBR, 0)

        def value(self):
            return self.getTypedRuleContext(CGrammarParser.ValueContext,0)


        def variable(self):
            return self.getTypedRuleContext(CGrammarParser.VariableContext,0)


        def MUL(self):
            return self.getToken(CGrammarParser.MUL, 0)

        def DIS(self):
            return self.getToken(CGrammarParser.DIS, 0)

        def MOD(self):
            return self.getToken(CGrammarParser.MOD, 0)

        def AND(self):
            return self.getToken(CGrammarParser.AND, 0)

        def OR(self):
            return self.getToken(CGrammarParser.OR, 0)

        def LT(self):
            return self.getToken(CGrammarParser.LT, 0)

        def GT(self):
            return self.getToken(CGrammarParser.GT, 0)

        def EQ(self):
            return self.getToken(CGrammarParser.EQ, 0)

        def LTE(self):
            return self.getToken(CGrammarParser.LTE, 0)

        def GTE(self):
            return self.getToken(CGrammarParser.GTE, 0)

        def NE(self):
            return self.getToken(CGrammarParser.NE, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_mathExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMathExpr" ):
                listener.enterMathExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMathExpr" ):
                listener.exitMathExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpr" ):
                return visitor.visitMathExpr(self)
            else:
                return visitor.visitChildren(self)



    def mathExpr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CGrammarParser.MathExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 6
        self.enterRecursionRule(localctx, 6, self.RULE_mathExpr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [CGrammarParser.MIN, CGrammarParser.PLUS, CGrammarParser.NOT]:
                self.state = 66
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.MIN) | (1 << CGrammarParser.PLUS) | (1 << CGrammarParser.NOT))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 67
                self.mathExpr(8)
                pass
            elif token in [CGrammarParser.LBR]:
                self.state = 68
                self.match(CGrammarParser.LBR)
                self.state = 69
                self.mathExpr(0)
                self.state = 70
                self.match(CGrammarParser.RBR)
                pass
            elif token in [CGrammarParser.INT, CGrammarParser.FLOAT, CGrammarParser.CHAR]:
                self.state = 72
                self.value()
                pass
            elif token in [CGrammarParser.MUL, CGrammarParser.VarName]:
                self.state = 73
                self.variable()
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 90
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 88
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = CGrammarParser.MathExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_mathExpr)
                        self.state = 76
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 77
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.MUL) | (1 << CGrammarParser.DIS) | (1 << CGrammarParser.MOD))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 78
                        self.mathExpr(8)
                        pass

                    elif la_ == 2:
                        localctx = CGrammarParser.MathExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_mathExpr)
                        self.state = 79
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 80
                        _la = self._input.LA(1)
                        if not(_la==CGrammarParser.MIN or _la==CGrammarParser.PLUS):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 81
                        self.mathExpr(7)
                        pass

                    elif la_ == 3:
                        localctx = CGrammarParser.MathExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_mathExpr)
                        self.state = 82
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 83
                        _la = self._input.LA(1)
                        if not(_la==CGrammarParser.AND or _la==CGrammarParser.OR):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 84
                        self.mathExpr(6)
                        pass

                    elif la_ == 4:
                        localctx = CGrammarParser.MathExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_mathExpr)
                        self.state = 85
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 86
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.LT) | (1 << CGrammarParser.GT) | (1 << CGrammarParser.EQ) | (1 << CGrammarParser.LTE) | (1 << CGrammarParser.GTE) | (1 << CGrammarParser.NE))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 87
                        self.mathExpr(5)
                        pass

             
                self.state = 92
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class BinOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(CGrammarParser.PLUS, 0)

        def MIN(self):
            return self.getToken(CGrammarParser.MIN, 0)

        def DIS(self):
            return self.getToken(CGrammarParser.DIS, 0)

        def MUL(self):
            return self.getToken(CGrammarParser.MUL, 0)

        def MOD(self):
            return self.getToken(CGrammarParser.MOD, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_binOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBinOp" ):
                listener.enterBinOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBinOp" ):
                listener.exitBinOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinOp" ):
                return visitor.visitBinOp(self)
            else:
                return visitor.visitChildren(self)




    def binOp(self):

        localctx = CGrammarParser.BinOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_binOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.MUL) | (1 << CGrammarParser.MIN) | (1 << CGrammarParser.DIS) | (1 << CGrammarParser.PLUS) | (1 << CGrammarParser.MOD))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(CGrammarParser.PLUS, 0)

        def MIN(self):
            return self.getToken(CGrammarParser.MIN, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_unOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnOp" ):
                listener.enterUnOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnOp" ):
                listener.exitUnOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnOp" ):
                return visitor.visitUnOp(self)
            else:
                return visitor.visitChildren(self)




    def unOp(self):

        localctx = CGrammarParser.UnOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_unOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            _la = self._input.LA(1)
            if not(_la==CGrammarParser.MIN or _la==CGrammarParser.PLUS):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AND(self):
            return self.getToken(CGrammarParser.AND, 0)

        def OR(self):
            return self.getToken(CGrammarParser.OR, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_logOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogOp" ):
                listener.enterLogOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogOp" ):
                listener.exitLogOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogOp" ):
                return visitor.visitLogOp(self)
            else:
                return visitor.visitChildren(self)




    def logOp(self):

        localctx = CGrammarParser.LogOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_logOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            _la = self._input.LA(1)
            if not(_la==CGrammarParser.AND or _la==CGrammarParser.OR):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LT(self):
            return self.getToken(CGrammarParser.LT, 0)

        def GT(self):
            return self.getToken(CGrammarParser.GT, 0)

        def EQ(self):
            return self.getToken(CGrammarParser.EQ, 0)

        def LTE(self):
            return self.getToken(CGrammarParser.LTE, 0)

        def GTE(self):
            return self.getToken(CGrammarParser.GTE, 0)

        def NE(self):
            return self.getToken(CGrammarParser.NE, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_compOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompOp" ):
                listener.enterCompOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompOp" ):
                listener.exitCompOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompOp" ):
                return visitor.visitCompOp(self)
            else:
                return visitor.visitChildren(self)




    def compOp(self):

        localctx = CGrammarParser.CompOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_compOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.LT) | (1 << CGrammarParser.GT) | (1 << CGrammarParser.EQ) | (1 << CGrammarParser.LTE) | (1 << CGrammarParser.GTE) | (1 << CGrammarParser.NE))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CHARTYPE(self):
            return self.getToken(CGrammarParser.CHARTYPE, 0)

        def FLOATTYPE(self):
            return self.getToken(CGrammarParser.FLOATTYPE, 0)

        def INTTYPE(self):
            return self.getToken(CGrammarParser.INTTYPE, 0)

        def type(self):
            return self.getTypedRuleContext(CGrammarParser.TypeContext,0)


        def MUL(self):
            return self.getToken(CGrammarParser.MUL, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitType" ):
                return visitor.visitType(self)
            else:
                return visitor.visitChildren(self)



    def type(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CGrammarParser.TypeContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_type, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [CGrammarParser.CHARTYPE]:
                self.state = 102
                self.match(CGrammarParser.CHARTYPE)
                pass
            elif token in [CGrammarParser.FLOATTYPE]:
                self.state = 103
                self.match(CGrammarParser.FLOATTYPE)
                pass
            elif token in [CGrammarParser.INTTYPE]:
                self.state = 104
                self.match(CGrammarParser.INTTYPE)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 111
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = CGrammarParser.TypeContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_type)
                    self.state = 107
                    if not self.precpred(self._ctx, 1):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                    self.state = 108
                    self.match(CGrammarParser.MUL) 
                self.state = 113
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(CGrammarParser.INT, 0)

        def FLOAT(self):
            return self.getToken(CGrammarParser.FLOAT, 0)

        def CHAR(self):
            return self.getToken(CGrammarParser.CHAR, 0)

        def getRuleIndex(self):
            return CGrammarParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValue" ):
                return visitor.visitValue(self)
            else:
                return visitor.visitChildren(self)




    def value(self):

        localctx = CGrammarParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 114
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << CGrammarParser.INT) | (1 << CGrammarParser.FLOAT) | (1 << CGrammarParser.CHAR))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrintfContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBR(self):
            return self.getToken(CGrammarParser.LBR, 0)

        def RBR(self):
            return self.getToken(CGrammarParser.RBR, 0)

        def VarName(self):
            return self.getToken(CGrammarParser.VarName, 0)

        def value(self):
            return self.getTypedRuleContext(CGrammarParser.ValueContext,0)


        def getRuleIndex(self):
            return CGrammarParser.RULE_printf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintf" ):
                listener.enterPrintf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintf" ):
                listener.exitPrintf(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintf" ):
                return visitor.visitPrintf(self)
            else:
                return visitor.visitChildren(self)




    def printf(self):

        localctx = CGrammarParser.PrintfContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_printf)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(CGrammarParser.T__0)
            self.state = 117
            self.match(CGrammarParser.LBR)
            self.state = 120
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [CGrammarParser.VarName]:
                self.state = 118
                self.match(CGrammarParser.VarName)
                pass
            elif token in [CGrammarParser.INT, CGrammarParser.FLOAT, CGrammarParser.CHAR]:
                self.state = 119
                self.value()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 122
            self.match(CGrammarParser.RBR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.expr_sempred
        self._predicates[3] = self.mathExpr_sempred
        self._predicates[8] = self.type_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 1)
         

    def mathExpr_sempred(self, localctx:MathExprContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 4)
         

    def type_sempred(self, localctx:TypeContext, predIndex:int):
            if predIndex == 5:
                return self.precpred(self._ctx, 1)
         




