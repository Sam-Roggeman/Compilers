# Generated from ./src/g4_files/CGrammar.g4 by ANTLR 4.9.3
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .CGrammarParser import CGrammarParser
else:
    from CGrammarParser import CGrammarParser

# This class defines a complete listener for a parse tree produced by CGrammarParser.
class CGrammarListener(ParseTreeListener):

    # Enter a parse tree produced by CGrammarParser#startRule.
    def enterStartRule(self, ctx:CGrammarParser.StartRuleContext):
        pass

    # Exit a parse tree produced by CGrammarParser#startRule.
    def exitStartRule(self, ctx:CGrammarParser.StartRuleContext):
        pass


    # Enter a parse tree produced by CGrammarParser#expr.
    def enterExpr(self, ctx:CGrammarParser.ExprContext):
        pass

    # Exit a parse tree produced by CGrammarParser#expr.
    def exitExpr(self, ctx:CGrammarParser.ExprContext):
        pass


    # Enter a parse tree produced by CGrammarParser#variable.
    def enterVariable(self, ctx:CGrammarParser.VariableContext):
        pass

    # Exit a parse tree produced by CGrammarParser#variable.
    def exitVariable(self, ctx:CGrammarParser.VariableContext):
        pass


    # Enter a parse tree produced by CGrammarParser#mathExpr.
    def enterMathExpr(self, ctx:CGrammarParser.MathExprContext):
        pass

    # Exit a parse tree produced by CGrammarParser#mathExpr.
    def exitMathExpr(self, ctx:CGrammarParser.MathExprContext):
        pass


    # Enter a parse tree produced by CGrammarParser#binOp.
    def enterBinOp(self, ctx:CGrammarParser.BinOpContext):
        pass

    # Exit a parse tree produced by CGrammarParser#binOp.
    def exitBinOp(self, ctx:CGrammarParser.BinOpContext):
        pass


    # Enter a parse tree produced by CGrammarParser#unOp.
    def enterUnOp(self, ctx:CGrammarParser.UnOpContext):
        pass

    # Exit a parse tree produced by CGrammarParser#unOp.
    def exitUnOp(self, ctx:CGrammarParser.UnOpContext):
        pass


    # Enter a parse tree produced by CGrammarParser#logOp.
    def enterLogOp(self, ctx:CGrammarParser.LogOpContext):
        pass

    # Exit a parse tree produced by CGrammarParser#logOp.
    def exitLogOp(self, ctx:CGrammarParser.LogOpContext):
        pass


    # Enter a parse tree produced by CGrammarParser#compOp.
    def enterCompOp(self, ctx:CGrammarParser.CompOpContext):
        pass

    # Exit a parse tree produced by CGrammarParser#compOp.
    def exitCompOp(self, ctx:CGrammarParser.CompOpContext):
        pass


    # Enter a parse tree produced by CGrammarParser#type.
    def enterType(self, ctx:CGrammarParser.TypeContext):
        pass

    # Exit a parse tree produced by CGrammarParser#type.
    def exitType(self, ctx:CGrammarParser.TypeContext):
        pass


    # Enter a parse tree produced by CGrammarParser#value.
    def enterValue(self, ctx:CGrammarParser.ValueContext):
        pass

    # Exit a parse tree produced by CGrammarParser#value.
    def exitValue(self, ctx:CGrammarParser.ValueContext):
        pass


    # Enter a parse tree produced by CGrammarParser#printf.
    def enterPrintf(self, ctx:CGrammarParser.PrintfContext):
        pass

    # Exit a parse tree produced by CGrammarParser#printf.
    def exitPrintf(self, ctx:CGrammarParser.PrintfContext):
        pass



del CGrammarParser