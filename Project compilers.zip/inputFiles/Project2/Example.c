//const int a = 3;
//int x = 5*(3/10 + 9/10);
//int y = x+1;
//x = 3;
//int const z = 2;

const int a = 5+5

//float y = x*2/( 2+1 * 2/3 +x) +8 * (8/4);
//float result = x + y;