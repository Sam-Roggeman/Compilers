int a = 5;
int* naam = &a;
int** b = &naam;
a = 3;
*naam = 6;