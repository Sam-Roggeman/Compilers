int a = 6.2f;
int b = 10 + 'a';
int c = 5 + 4.7f;
int d = 3 + '5';

float e = 15;
float f = 34;
float g =  1.5f + 2;
float h = 5.6f + 3;

char i = 36;
char j = 9.3f;
char k = 5 + 36;
char l = '7' + 19.0f;