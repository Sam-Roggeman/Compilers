int a = 5;
a = 1 + 2;
float _b = 2.0f;
char _v2 = 'g';