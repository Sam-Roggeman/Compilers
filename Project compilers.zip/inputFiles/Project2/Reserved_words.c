const int a = 3;
int b = 5;
int c = b + a;