// this is a linecomment
int x = 3;
// this is also a linecomment