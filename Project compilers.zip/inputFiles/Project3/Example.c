/*
* My program
*/
int x = 5*(3/10 + 9/10);
float y = x*2/( 2+1 * 2/3 +x) +8 * (8/4);
float result = x + y; //calculate the result
printf(result); //show the result
