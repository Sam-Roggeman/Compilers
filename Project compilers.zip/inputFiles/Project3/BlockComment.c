/**
* this is a block comment
*/
int i = 5;
/**
* idem
*/